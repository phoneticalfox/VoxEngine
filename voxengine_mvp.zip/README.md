# VoxEngine

VoxEngine is a local-first speech engine you can embed in any app that needs text-to-speech.
It provides:

- Headless HTTP API (FastAPI)
- CLI for quick testing / automation
- Adapter layer so backends can swap without rewriting your app

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .
voxengine serve
```

```bash
curl http://127.0.0.1:7341/health
```

## TTS

Default backend is Piper (expects `piper` on PATH):

```bash
voxengine tts speak "hello there" --backend piper --model /path/to/en_US-amy.onnx --out hello.wav
```
