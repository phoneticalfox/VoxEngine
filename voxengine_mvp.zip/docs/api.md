# API

## GET /health
Returns engine status.

## POST /tts/speak
Request:
```json
{ "text": "hello", "backend": "piper", "model_path": "/path/model.onnx" }
```
