from __future__ import annotations
import json
from pathlib import Path
from typing import Optional
import typer
from rich import print
from voxengine.core.engine import Engine, EngineConfig
from voxengine.core.logging import configure_logging

app = typer.Typer(add_completion=False, help="VoxEngine CLI.")
tts_app = typer.Typer(help="Text-to-speech commands.")
app.add_typer(tts_app, name="tts")

def _engine() -> Engine:
    configure_logging()
    return Engine(EngineConfig.load())

@app.command()
def serve(host: str = "127.0.0.1", port: int = 7341):
    from voxengine.api.server import run
    run(host=host, port=port)

@app.command()
def doctor():
    print(json.dumps(_engine().doctor(), indent=2))

@tts_app.command("speak")
def speak(
    text: str,
    out: Path = typer.Option(Path("out.wav"), "--out", "-o"),
    backend: str = typer.Option("piper", "--backend"),
    model: Optional[Path] = typer.Option(None, "--model"),
    voice: Optional[str] = typer.Option(None, "--voice"),
):
    res = _engine().tts_speak(text=text, out_path=out, backend=backend, model_path=model, voice=voice)
    print(f"[green]Wrote[/green] {res['path']}")
