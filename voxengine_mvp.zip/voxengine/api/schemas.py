from __future__ import annotations
from pathlib import Path
from typing import Optional
from pydantic import BaseModel, Field

class SpeakRequest(BaseModel):
    text: str = Field(..., min_length=1)
    backend: str = "piper"
    model_path: Optional[Path] = None
    voice: Optional[str] = None

class SpeakResponse(BaseModel):
    backend: str
    path: str
    sample_rate: int
    download_url: Optional[str] = None
