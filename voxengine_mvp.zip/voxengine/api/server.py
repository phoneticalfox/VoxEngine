from __future__ import annotations
from fastapi import FastAPI
from fastapi.responses import FileResponse
import uvicorn
from voxengine.core.engine import Engine, EngineConfig
from voxengine.core.logging import configure_logging
from voxengine.api.schemas import SpeakRequest, SpeakResponse

def create_app() -> FastAPI:
    configure_logging()
    cfg = EngineConfig.load()
    eng = Engine(cfg)
    app = FastAPI(title="VoxEngine", version=cfg.version)

    @app.get("/health")
    def health():
        return {"status": "ok", "version": cfg.version}

    @app.get("/doctor")
    def doctor():
        return eng.doctor()

    @app.post("/tts/speak", response_model=SpeakResponse)
    def tts_speak(req: SpeakRequest):
        result = eng.tts_speak(text=req.text, backend=req.backend, model_path=req.model_path, voice=req.voice)
        return SpeakResponse(**result, download_url=f"/tts/file?path={result['path']}")

    @app.get("/tts/file")
    def tts_file(path: str):
        return FileResponse(path, media_type="audio/wav", filename="speech.wav")

    return app

def run(host: str = "127.0.0.1", port: int = 7341):
    uvicorn.run(create_app(), host=host, port=port)
