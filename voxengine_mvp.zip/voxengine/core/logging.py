from __future__ import annotations
import logging, os

def configure_logging():
    level = os.getenv("VOXENGINE_LOG_LEVEL", "INFO").upper()
    logging.basicConfig(level=level, format="%(levelname)s %(name)s: %(message)s")
