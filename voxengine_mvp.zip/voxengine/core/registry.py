from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, List
from voxengine.adapters.tts.piper import PiperTTSAdapter

@dataclass
class AdapterRegistry:
    tts: Dict[str, object]

    @staticmethod
    def default() -> "AdapterRegistry":
        return AdapterRegistry(tts={"piper": PiperTTSAdapter()})

    def list_tts(self) -> List[dict]:
        return [self.tts[k].about() for k in sorted(self.tts.keys())]

    def get_tts(self, name: str):
        if name not in self.tts:
            raise KeyError(f"Unknown TTS backend '{name}'. Available: {sorted(self.tts.keys())}")
        return self.tts[name]
