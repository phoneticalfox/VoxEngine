from __future__ import annotations
import json, shutil
from pathlib import Path

def add_voice_sample(project_path: Path, voice_id: str, sample_wav: Path) -> Path:
    if not sample_wav.exists():
        raise FileNotFoundError(sample_wav)
    voices_dir = project_path / "cast" / "voices" / voice_id
    voices_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(sample_wav, voices_dir / "sample.wav")
    (voices_dir / "meta.json").write_text(json.dumps({"voice_id": voice_id}, indent=2), encoding="utf-8")
    return voices_dir
