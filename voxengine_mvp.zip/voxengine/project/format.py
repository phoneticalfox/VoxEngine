from __future__ import annotations
import json
from pathlib import Path
from typing import List

PROJECT_FILE = "project.json"

def init_project(path: Path):
    path.mkdir(parents=True, exist_ok=True)
    (path / "cast" / "voices").mkdir(parents=True, exist_ok=True)
    (path / "scripts").mkdir(parents=True, exist_ok=True)
    (path / "renders").mkdir(parents=True, exist_ok=True)
    meta = {"schema_version": 1, "name": path.name, "created_by": "voxengine"}
    (path / PROJECT_FILE).write_text(json.dumps(meta, indent=2), encoding="utf-8")

def validate_project(path: Path) -> List[str]:
    issues: List[str] = []
    if not (path / PROJECT_FILE).exists():
        issues.append(f"Missing {PROJECT_FILE}")
    for req in ["cast/voices", "scripts", "renders"]:
        if not (path / req).exists():
            issues.append(f"Missing folder: {req}")
    return issues
