from voxengine.core.engine import Engine, EngineConfig
print(Engine(EngineConfig.load()).doctor())
