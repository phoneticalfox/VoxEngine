"""Resampling helpers (placeholder)."""
