"""Audio trimming helpers (placeholder)."""
