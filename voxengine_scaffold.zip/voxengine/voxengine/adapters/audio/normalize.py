"""Audio normalization helpers (placeholder)."""
